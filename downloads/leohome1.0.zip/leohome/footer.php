
    <?php wp_nav_menu( array('theme_location'  => 'footer_menu' ,'sort_column' => 'menu_order', 'container_class' => 'footer', 'after' => '&nbsp;<li class="menu-divider">|</li>' ) ); ?>
	

	<?php wp_footer(); ?>

</body>
</html>