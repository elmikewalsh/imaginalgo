<?php get_header(); ?>

		<h2><?php echo __('huh.'); ?></h2>
        

        <p><?php echo __('The page you are looking for does not seem to be here. Perhaps I decluttered it. Crazy minimalists!'); ?></p>

        <p><?php echo __('Try <a href="/">the home page</a>.'); ?></p>
	
    <h5><?php edit_post_link(__('Edit'), '<p>', '</p>'); ?></h5>


	<?php get_footer(); ?>