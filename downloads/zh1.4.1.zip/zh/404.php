<?php get_header(); ?>


		<div class="entry">

	<h2><?php echo __('page lost, a haiku'); ?></h2>
		<div class="post">

<br>
<p><?php echo __('our search is lonely'); ?></p>

<p><?php echo __('a footprint left in pure snow'); ?></p>

<p><?php echo __('blown into'); ?> <a href="<?php echo get_option('home'); ?>/"><?php echo __('nothing'); ?></a></p>

	</div>
	</div>

<?php get_sidebar(); ?>
	</div>

<?php get_footer(); ?>