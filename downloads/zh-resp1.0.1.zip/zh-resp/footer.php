<div id="footer">

<?php wp_nav_menu( array('theme_location'  => 'footer_menu' ,'sort_column' => 'menu_order', 'container_class' => 'footer_menu' ) ); ?>

</div>

<!-- WP Footer -->
<?php wp_footer(); ?>

