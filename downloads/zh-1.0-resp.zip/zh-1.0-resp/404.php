<?php get_header(); ?>

	
	<!-- Outer Start -->
	<div id="outer">
		
		<!-- Wrap Start -->
		<div id="wrap">
			
			
			<!-- Sidebar Start -->
<?php get_sidebar(); ?>
			<!-- Sidebar End -->
			
			<!-- Content Start -->
			<div id="content">
				
		<div class="entry">

	<h2>page lost, a haiku</h2>
		<div class="post">

<br>
<p>our search is lonely</p>

<p>a footprint left in pure snow</p>

<p>blown into <a href="<?php echo get_option('home'); ?>/">nothing</a></p>

	</div>
	</div>

			</div>
			<!-- Content End -->			
			<div class="push"></div>
			
		</div>
		<!-- Wrap End -->
		
<?php get_footer(); ?>
	</div>
	<!-- Outer End -->
	
</body>
</html>