<?php get_header(); ?>

	
	<!-- Outer Start -->
	<div id="outer">
		
		<!-- Wrap Start -->
		<div id="wrap">
			
			
			<!-- Sidebar Start -->
<?php get_sidebar(); ?>
			<!-- Sidebar End -->
			
			<!-- Content Start -->
			<div id="content">
				
		<div class="entry">

			<h2><?php the_title(); ?></h2>


			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post">

				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>


		</div>



	<small><?php edit_post_link('Edit', '<p>', '</p>'); ?></small>

<br />
				<div class="home_bottom"></div>
<br />

<div class="navigation">
<div class="alignleft">

<?php if (get_adjacent_post(false, '', true)): // if there are older posts ?>
    <h5>Posted: <?php the_date('m.d.Y'); ?></h5>
<p>Previous post: <?php previous_post_link('%link'); ?></p>
<?php endif; ?>

 </div>
<div class="alignright">

<?php if (get_adjacent_post(false, '', false)): // if there are newer posts ?>
    <p>Next post: <?php next_post_link('%link'); ?></p>
<?php endif; ?>

</div>
</div>
		</div>

	<?php endwhile; else: ?>

		<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>

			</div>
			<!-- Content End -->			
			<div class="push"></div>
			
		</div>
		<!-- Wrap End -->
		
<?php get_footer(); ?>
	</div>
	<!-- Outer End -->
	
</body>
</html>