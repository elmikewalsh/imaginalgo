<?php get_header(); ?>


		<div class="entry">

	<h2>page lost, a haiku</h2>
		<div class="post">

<br>
<p>our search is lonely</p>

<p>a footprint left in pure snow</p>

<p>blown into <a href="<?php echo get_option('home'); ?>/">nothing</a></p>

	</div>
	</div>

<?php get_sidebar(); ?>
	</div>

<?php get_footer(); ?>