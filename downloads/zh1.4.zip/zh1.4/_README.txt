zh 1.4 readme

Update Author: Mike Walsh
Original Author: Leo Babauta
Update Author URI: http://imaginalgo.com
Author URI: http://leobabauta.com
V 1.4 Theme URI: http://themes.imaginalgo.com/zenhabits/
Theme URI: http://zenhabits.net/theme/


This is a simple update to the zh Wordpress theme which eliminated the need to edit many files manually by integrating the theme with various Wordpress functions. 

The original readme file follows.

------


zh readme

Author: Leo Babauta
Author URI: http://leobabauta.com
Theme URI: http://zenhabits.net/theme/


zh is an extremely minimalist theme that focuses on the content without distractions. It has a single sidebar. No header. No widgets. No comments. No search. No dynamic sidebar. No nothing.

This theme is uncopyrighted -- use as you like, spread it, sell it, do whatever you want. Thanks and enjoy.


Basic Setup
---------------------------------
Please see the Install page for important instructions:

http://zenhabits.net/install/

This theme is designed to be as minimalist as possible, so I've stripped out a lot of functions that other themes have. That's the choice I've made and I like it that way.

This theme is "as is" - any bugs, you need to fix it. Any changes you want, you'll need to make them.