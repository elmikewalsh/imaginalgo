<?php get_header(); ?>

		<h2><?php echo __('page lost, a haiku'); ?></h2>

		<div class="post">

			<br />
			<center>
			<p><?php echo __('our search is lonely'); ?></p>

			<p><?php echo __('a footprint left in pure snow'); ?></p>

			<p><?php echo __('blown into'); ?> <a href="<?php echo get_option('home'); ?>/"><?php echo __('nothing'); ?></a></p>
			</center>

		</div> <!-- /end .post -->

	</div>  <!-- /end .container -->

	<?php wp_footer(); ?>

</body>
</html>