zh2 readme

Author: Leo Babauta
Author URI: http://leobabauta.com
Theme URI: http://zenhabits.net/theme/


zh2 is an extremely minimalist theme that focuses on the content without distractions. It has the content and almost nothing else. No sidebar. No header. No widgets. No comments. No search. No dynamic sidebar. No nothing.

This theme is uncopyrighted -- use as you like, spread it, sell it, do whatever you want. Thanks and enjoy.


Basic Setup
---------------------------------
You'll need to edit several pages in the Wordpress theme editor - go to Wordpress admin, then Appearance, then editor (after you've activated this theme).

Then go to this page for instructions: http://zenhabits.net/install/

This theme is designed to be as minimalist as possible, so I've stripped out a lot of functions that other themes have. That's the choice I've made and I like it that way.

This theme is "as is" - any bugs, you need to fix it. Any changes you want, you'll need to make them.


Updates
---------------------------------
By request, I've made the following updates since releasing the theme:
* Added comments - just make sure your comments are turned on in the Wordpress Settings -> Discussion options.
* Updated the header to not show a colon before the blog title on the front page.